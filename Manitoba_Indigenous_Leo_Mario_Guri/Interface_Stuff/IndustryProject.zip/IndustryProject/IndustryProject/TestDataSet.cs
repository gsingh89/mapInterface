﻿namespace IndustryProject
{


    partial class TestDataSet
    {
    }
}
