﻿namespace IndustryProject
{
    partial class newplace
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(newplace));
            this.grpNewPlace = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDateChanged = new System.Windows.Forms.TextBox();
            this.lblDateChanged = new System.Windows.Forms.Label();
            this.txtActFrom = new System.Windows.Forms.TextBox();
            this.txtActTo = new System.Windows.Forms.TextBox();
            this.lblActFrom = new System.Windows.Forms.Label();
            this.lblActTo = new System.Windows.Forms.Label();
            this.txtMS250 = new System.Windows.Forms.TextBox();
            this.txtMS50 = new System.Windows.Forms.TextBox();
            this.lblMS50 = new System.Windows.Forms.Label();
            this.lblMS250 = new System.Windows.Forms.Label();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.lblstatus = new System.Windows.Forms.Label();
            this.txtFID = new System.Windows.Forms.TextBox();
            this.lblFID = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.lbllongitude = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.lbllatitude = new System.Windows.Forms.Label();
            this.txtFeature = new System.Windows.Forms.TextBox();
            this.lblFeature = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.grpCasualty = new System.Windows.Forms.GroupBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.lblAdditionalInfo = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.lblBuried = new System.Windows.Forms.Label();
            this.lblServed = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.lblDateDeceased = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lblSurname = new System.Windows.Forms.Label();
            this.lblGivenname = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblRegNo = new System.Windows.Forms.Label();
            this.txtCommunity = new System.Windows.Forms.TextBox();
            this.lblCommunity = new System.Windows.Forms.Label();
            this.txtCname = new System.Windows.Forms.TextBox();
            this.lblCname = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.grpNewPlace.SuspendLayout();
            this.grpCasualty.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpNewPlace
            // 
            this.grpNewPlace.Controls.Add(this.label6);
            this.grpNewPlace.Controls.Add(this.label5);
            this.grpNewPlace.Controls.Add(this.label4);
            this.grpNewPlace.Controls.Add(this.label3);
            this.grpNewPlace.Controls.Add(this.label2);
            this.grpNewPlace.Controls.Add(this.label1);
            this.grpNewPlace.Controls.Add(this.txtDateChanged);
            this.grpNewPlace.Controls.Add(this.lblDateChanged);
            this.grpNewPlace.Controls.Add(this.txtActFrom);
            this.grpNewPlace.Controls.Add(this.txtActTo);
            this.grpNewPlace.Controls.Add(this.lblActFrom);
            this.grpNewPlace.Controls.Add(this.lblActTo);
            this.grpNewPlace.Controls.Add(this.txtMS250);
            this.grpNewPlace.Controls.Add(this.txtMS50);
            this.grpNewPlace.Controls.Add(this.lblMS50);
            this.grpNewPlace.Controls.Add(this.lblMS250);
            this.grpNewPlace.Controls.Add(this.txtStatus);
            this.grpNewPlace.Controls.Add(this.lblstatus);
            this.grpNewPlace.Controls.Add(this.txtFID);
            this.grpNewPlace.Controls.Add(this.lblFID);
            this.grpNewPlace.Controls.Add(this.textBox8);
            this.grpNewPlace.Controls.Add(this.textBox7);
            this.grpNewPlace.Controls.Add(this.textBox6);
            this.grpNewPlace.Controls.Add(this.lbllongitude);
            this.grpNewPlace.Controls.Add(this.textBox5);
            this.grpNewPlace.Controls.Add(this.textBox4);
            this.grpNewPlace.Controls.Add(this.textBox3);
            this.grpNewPlace.Controls.Add(this.lbllatitude);
            this.grpNewPlace.Controls.Add(this.txtFeature);
            this.grpNewPlace.Controls.Add(this.lblFeature);
            this.grpNewPlace.Controls.Add(this.txtName);
            this.grpNewPlace.Controls.Add(this.lblName);
            this.grpNewPlace.Location = new System.Drawing.Point(32, 29);
            this.grpNewPlace.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.grpNewPlace.Name = "grpNewPlace";
            this.grpNewPlace.Padding = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.grpNewPlace.Size = new System.Drawing.Size(765, 928);
            this.grpNewPlace.TabIndex = 0;
            this.grpNewPlace.TabStop = false;
            this.grpNewPlace.Text = "New Place";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 5.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(466, 298);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 20);
            this.label6.TabIndex = 31;
            this.label6.Text = "Seconds";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 5.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(328, 298);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 20);
            this.label5.TabIndex = 30;
            this.label5.Text = "Minutes";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 5.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(197, 298);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 20);
            this.label4.TabIndex = 29;
            this.label4.Text = "Degrees";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 5.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(466, 213);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 20);
            this.label3.TabIndex = 28;
            this.label3.Text = "Seconds";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 5.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(328, 213);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 20);
            this.label2.TabIndex = 27;
            this.label2.Text = "Minutes";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 5.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(197, 213);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 20);
            this.label1.TabIndex = 26;
            this.label1.Text = "Degrees";
            // 
            // txtDateChanged
            // 
            this.txtDateChanged.Location = new System.Drawing.Point(245, 785);
            this.txtDateChanged.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtDateChanged.Name = "txtDateChanged";
            this.txtDateChanged.Size = new System.Drawing.Size(239, 38);
            this.txtDateChanged.TabIndex = 25;
            // 
            // lblDateChanged
            // 
            this.lblDateChanged.AutoSize = true;
            this.lblDateChanged.Location = new System.Drawing.Point(19, 792);
            this.lblDateChanged.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblDateChanged.Name = "lblDateChanged";
            this.lblDateChanged.Size = new System.Drawing.Size(206, 32);
            this.lblDateChanged.TabIndex = 24;
            this.lblDateChanged.Text = "Date Changed:";
            // 
            // txtActFrom
            // 
            this.txtActFrom.Location = new System.Drawing.Point(176, 715);
            this.txtActFrom.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtActFrom.Name = "txtActFrom";
            this.txtActFrom.Size = new System.Drawing.Size(239, 38);
            this.txtActFrom.TabIndex = 23;
            // 
            // txtActTo
            // 
            this.txtActTo.Location = new System.Drawing.Point(181, 644);
            this.txtActTo.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtActTo.Name = "txtActTo";
            this.txtActTo.Size = new System.Drawing.Size(233, 38);
            this.txtActTo.TabIndex = 22;
            // 
            // lblActFrom
            // 
            this.lblActFrom.AutoSize = true;
            this.lblActFrom.Location = new System.Drawing.Point(21, 723);
            this.lblActFrom.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblActFrom.Name = "lblActFrom";
            this.lblActFrom.Size = new System.Drawing.Size(136, 32);
            this.lblActFrom.TabIndex = 21;
            this.lblActFrom.Text = "Act From:";
            // 
            // lblActTo
            // 
            this.lblActTo.AutoSize = true;
            this.lblActTo.Location = new System.Drawing.Point(21, 658);
            this.lblActTo.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblActTo.Name = "lblActTo";
            this.lblActTo.Size = new System.Drawing.Size(104, 32);
            this.lblActTo.TabIndex = 20;
            this.lblActTo.Text = "Act To:";
            // 
            // txtMS250
            // 
            this.txtMS250.Location = new System.Drawing.Point(181, 519);
            this.txtMS250.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtMS250.Name = "txtMS250";
            this.txtMS250.Size = new System.Drawing.Size(561, 38);
            this.txtMS250.TabIndex = 19;
            // 
            // txtMS50
            // 
            this.txtMS50.Location = new System.Drawing.Point(181, 582);
            this.txtMS50.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtMS50.Name = "txtMS50";
            this.txtMS50.Size = new System.Drawing.Size(561, 38);
            this.txtMS50.TabIndex = 18;
            // 
            // lblMS50
            // 
            this.lblMS50.AutoSize = true;
            this.lblMS50.Location = new System.Drawing.Point(16, 589);
            this.lblMS50.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblMS50.Name = "lblMS50";
            this.lblMS50.Size = new System.Drawing.Size(97, 32);
            this.lblMS50.TabIndex = 17;
            this.lblMS50.Text = "MS50:";
            // 
            // lblMS250
            // 
            this.lblMS250.AutoSize = true;
            this.lblMS250.Location = new System.Drawing.Point(16, 522);
            this.lblMS250.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblMS250.Name = "lblMS250";
            this.lblMS250.Size = new System.Drawing.Size(113, 32);
            this.lblMS250.TabIndex = 16;
            this.lblMS250.Text = "MS250:";
            // 
            // txtStatus
            // 
            this.txtStatus.Location = new System.Drawing.Point(181, 452);
            this.txtStatus.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(561, 38);
            this.txtStatus.TabIndex = 15;
            // 
            // lblstatus
            // 
            this.lblstatus.AutoSize = true;
            this.lblstatus.Location = new System.Drawing.Point(16, 455);
            this.lblstatus.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblstatus.Name = "lblstatus";
            this.lblstatus.Size = new System.Drawing.Size(104, 32);
            this.lblstatus.TabIndex = 14;
            this.lblstatus.Text = "Status:";
            // 
            // txtFID
            // 
            this.txtFID.Location = new System.Drawing.Point(181, 389);
            this.txtFID.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtFID.Name = "txtFID";
            this.txtFID.Size = new System.Drawing.Size(561, 38);
            this.txtFID.TabIndex = 13;
            // 
            // lblFID
            // 
            this.lblFID.AutoSize = true;
            this.lblFID.Location = new System.Drawing.Point(16, 396);
            this.lblFID.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblFID.Name = "lblFID";
            this.lblFID.Size = new System.Drawing.Size(67, 32);
            this.lblFID.TabIndex = 12;
            this.lblFID.Text = "FID:";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(182, 326);
            this.textBox8.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(105, 38);
            this.textBox8.TabIndex = 11;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(309, 326);
            this.textBox7.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(105, 38);
            this.textBox7.TabIndex = 10;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(437, 326);
            this.textBox6.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(137, 38);
            this.textBox6.TabIndex = 9;
            // 
            // lbllongitude
            // 
            this.lbllongitude.AutoSize = true;
            this.lbllongitude.Location = new System.Drawing.Point(16, 326);
            this.lbllongitude.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lbllongitude.Name = "lbllongitude";
            this.lbllongitude.Size = new System.Drawing.Size(150, 32);
            this.lbllongitude.TabIndex = 8;
            this.lbllongitude.Text = "Longitude:";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(437, 243);
            this.textBox5.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(137, 38);
            this.textBox5.TabIndex = 7;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(309, 243);
            this.textBox4.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(105, 38);
            this.textBox4.TabIndex = 6;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(182, 243);
            this.textBox3.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(105, 38);
            this.textBox3.TabIndex = 5;
            // 
            // lbllatitude
            // 
            this.lbllatitude.AutoSize = true;
            this.lbllatitude.Location = new System.Drawing.Point(16, 236);
            this.lbllatitude.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lbllatitude.Name = "lbllatitude";
            this.lbllatitude.Size = new System.Drawing.Size(126, 32);
            this.lbllatitude.TabIndex = 4;
            this.lbllatitude.Text = "Latitude:";
            // 
            // txtFeature
            // 
            this.txtFeature.Location = new System.Drawing.Point(181, 155);
            this.txtFeature.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtFeature.Name = "txtFeature";
            this.txtFeature.Size = new System.Drawing.Size(561, 38);
            this.txtFeature.TabIndex = 3;
            // 
            // lblFeature
            // 
            this.lblFeature.AutoSize = true;
            this.lblFeature.Location = new System.Drawing.Point(16, 155);
            this.lblFeature.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblFeature.Name = "lblFeature";
            this.lblFeature.Size = new System.Drawing.Size(121, 32);
            this.lblFeature.TabIndex = 2;
            this.lblFeature.Text = "Feature:";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(181, 79);
            this.txtName.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(561, 38);
            this.txtName.TabIndex = 1;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(21, 86);
            this.lblName.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(98, 32);
            this.lblName.TabIndex = 1;
            this.lblName.Text = "Name:";
            // 
            // grpCasualty
            // 
            this.grpCasualty.Controls.Add(this.richTextBox1);
            this.grpCasualty.Controls.Add(this.lblAdditionalInfo);
            this.grpCasualty.Controls.Add(this.textBox12);
            this.grpCasualty.Controls.Add(this.textBox11);
            this.grpCasualty.Controls.Add(this.lblBuried);
            this.grpCasualty.Controls.Add(this.lblServed);
            this.grpCasualty.Controls.Add(this.textBox10);
            this.grpCasualty.Controls.Add(this.lblDateDeceased);
            this.grpCasualty.Controls.Add(this.textBox9);
            this.grpCasualty.Controls.Add(this.textBox2);
            this.grpCasualty.Controls.Add(this.lblSurname);
            this.grpCasualty.Controls.Add(this.lblGivenname);
            this.grpCasualty.Controls.Add(this.textBox1);
            this.grpCasualty.Controls.Add(this.lblRegNo);
            this.grpCasualty.Controls.Add(this.txtCommunity);
            this.grpCasualty.Controls.Add(this.lblCommunity);
            this.grpCasualty.Controls.Add(this.txtCname);
            this.grpCasualty.Controls.Add(this.lblCname);
            this.grpCasualty.Location = new System.Drawing.Point(813, 29);
            this.grpCasualty.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.grpCasualty.Name = "grpCasualty";
            this.grpCasualty.Padding = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.grpCasualty.Size = new System.Drawing.Size(831, 928);
            this.grpCasualty.TabIndex = 1;
            this.grpCasualty.TabStop = false;
            this.grpCasualty.Text = "Casualty";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(16, 699);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(769, 209);
            this.richTextBox1.TabIndex = 19;
            this.richTextBox1.Text = "";
            // 
            // lblAdditionalInfo
            // 
            this.lblAdditionalInfo.AutoSize = true;
            this.lblAdditionalInfo.Location = new System.Drawing.Point(16, 661);
            this.lblAdditionalInfo.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblAdditionalInfo.Name = "lblAdditionalInfo";
            this.lblAdditionalInfo.Size = new System.Drawing.Size(205, 32);
            this.lblAdditionalInfo.TabIndex = 18;
            this.lblAdditionalInfo.Text = "Additional Info:";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(139, 575);
            this.textBox12.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(193, 38);
            this.textBox12.TabIndex = 17;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(139, 508);
            this.textBox11.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(193, 38);
            this.textBox11.TabIndex = 16;
            // 
            // lblBuried
            // 
            this.lblBuried.AutoSize = true;
            this.lblBuried.Location = new System.Drawing.Point(16, 582);
            this.lblBuried.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblBuried.Name = "lblBuried";
            this.lblBuried.Size = new System.Drawing.Size(106, 32);
            this.lblBuried.TabIndex = 15;
            this.lblBuried.Text = "Buried:";
            // 
            // lblServed
            // 
            this.lblServed.AutoSize = true;
            this.lblServed.Location = new System.Drawing.Point(16, 515);
            this.lblServed.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblServed.Name = "lblServed";
            this.lblServed.Size = new System.Drawing.Size(113, 32);
            this.lblServed.TabIndex = 14;
            this.lblServed.Text = "Served:";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(240, 436);
            this.textBox10.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(561, 38);
            this.textBox10.TabIndex = 13;
            // 
            // lblDateDeceased
            // 
            this.lblDateDeceased.AutoSize = true;
            this.lblDateDeceased.Location = new System.Drawing.Point(16, 446);
            this.lblDateDeceased.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblDateDeceased.Name = "lblDateDeceased";
            this.lblDateDeceased.Size = new System.Drawing.Size(218, 32);
            this.lblDateDeceased.TabIndex = 12;
            this.lblDateDeceased.Text = "Date Deceased:";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(179, 358);
            this.textBox9.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(561, 38);
            this.textBox9.TabIndex = 11;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(171, 291);
            this.textBox2.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(561, 38);
            this.textBox2.TabIndex = 10;
            // 
            // lblSurname
            // 
            this.lblSurname.AutoSize = true;
            this.lblSurname.Location = new System.Drawing.Point(16, 298);
            this.lblSurname.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblSurname.Name = "lblSurname";
            this.lblSurname.Size = new System.Drawing.Size(138, 32);
            this.lblSurname.TabIndex = 9;
            this.lblSurname.Text = "Surname:";
            // 
            // lblGivenname
            // 
            this.lblGivenname.AutoSize = true;
            this.lblGivenname.Location = new System.Drawing.Point(11, 365);
            this.lblGivenname.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblGivenname.Name = "lblGivenname";
            this.lblGivenname.Size = new System.Drawing.Size(169, 32);
            this.lblGivenname.TabIndex = 8;
            this.lblGivenname.Text = "Givenname:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(171, 219);
            this.textBox1.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(561, 38);
            this.textBox1.TabIndex = 7;
            // 
            // lblRegNo
            // 
            this.lblRegNo.AutoSize = true;
            this.lblRegNo.Location = new System.Drawing.Point(16, 229);
            this.lblRegNo.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblRegNo.Name = "lblRegNo";
            this.lblRegNo.Size = new System.Drawing.Size(126, 32);
            this.lblRegNo.TabIndex = 6;
            this.lblRegNo.Text = "Reg. No:";
            // 
            // txtCommunity
            // 
            this.txtCommunity.Location = new System.Drawing.Point(171, 148);
            this.txtCommunity.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtCommunity.Name = "txtCommunity";
            this.txtCommunity.Size = new System.Drawing.Size(561, 38);
            this.txtCommunity.TabIndex = 5;
            // 
            // lblCommunity
            // 
            this.lblCommunity.AutoSize = true;
            this.lblCommunity.Location = new System.Drawing.Point(16, 155);
            this.lblCommunity.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblCommunity.Name = "lblCommunity";
            this.lblCommunity.Size = new System.Drawing.Size(166, 32);
            this.lblCommunity.TabIndex = 4;
            this.lblCommunity.Text = "Community:";
            // 
            // txtCname
            // 
            this.txtCname.Location = new System.Drawing.Point(171, 86);
            this.txtCname.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.txtCname.Name = "txtCname";
            this.txtCname.Size = new System.Drawing.Size(561, 38);
            this.txtCname.TabIndex = 3;
            // 
            // lblCname
            // 
            this.lblCname.AutoSize = true;
            this.lblCname.Location = new System.Drawing.Point(16, 86);
            this.lblCname.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblCname.Name = "lblCname";
            this.lblCname.Size = new System.Drawing.Size(98, 32);
            this.lblCname.TabIndex = 2;
            this.lblCname.Text = "Name:";
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(1253, 985);
            this.btnExit.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(200, 55);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(952, 985);
            this.btnSave.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(200, 55);
            this.btnSave.TabIndex = 4;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            // 
            // newplace
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1661, 1068);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.grpCasualty);
            this.Controls.Add(this.grpNewPlace);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.MaximizeBox = false;
            this.Name = "newplace";
            this.Text = "newplace";
            this.Load += new System.EventHandler(this.newplace_Load);
            this.grpNewPlace.ResumeLayout(false);
            this.grpNewPlace.PerformLayout();
            this.grpCasualty.ResumeLayout(false);
            this.grpCasualty.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpNewPlace;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtFeature;
        private System.Windows.Forms.Label lblFeature;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label lbllatitude;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label lbllongitude;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox txtMS250;
        private System.Windows.Forms.TextBox txtMS50;
        private System.Windows.Forms.Label lblMS50;
        private System.Windows.Forms.Label lblMS250;
        private System.Windows.Forms.TextBox txtStatus;
        private System.Windows.Forms.Label lblstatus;
        private System.Windows.Forms.TextBox txtFID;
        private System.Windows.Forms.Label lblFID;
        private System.Windows.Forms.TextBox txtActFrom;
        private System.Windows.Forms.TextBox txtActTo;
        private System.Windows.Forms.Label lblActFrom;
        private System.Windows.Forms.Label lblActTo;
        private System.Windows.Forms.TextBox txtDateChanged;
        private System.Windows.Forms.Label lblDateChanged;
        private System.Windows.Forms.GroupBox grpCasualty;
        private System.Windows.Forms.TextBox txtCname;
        private System.Windows.Forms.Label lblCname;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtCommunity;
        private System.Windows.Forms.Label lblCommunity;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblRegNo;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label lblSurname;
        private System.Windows.Forms.Label lblGivenname;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label lblBuried;
        private System.Windows.Forms.Label lblServed;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label lblDateDeceased;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label lblAdditionalInfo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}