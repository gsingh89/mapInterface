﻿namespace IndustryProject
{
    partial class frmCasualty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCasualty));
            this.grpCasualty = new System.Windows.Forms.GroupBox();
            this.vScrollBar1 = new System.Windows.Forms.VScrollBar();
            this.grpDetails = new System.Windows.Forms.GroupBox();
            this.lblNextOfKinNameBox = new System.Windows.Forms.Label();
            this.lblServedBox = new System.Windows.Forms.Label();
            this.lblBuriedBox = new System.Windows.Forms.Label();
            this.lblNextKin = new System.Windows.Forms.Label();
            this.lblServed = new System.Windows.Forms.Label();
            this.lblBuried = new System.Windows.Forms.Label();
            this.lblDateOfDeathBox = new System.Windows.Forms.Label();
            this.lblRankBox = new System.Windows.Forms.Label();
            this.lblRegNoBox = new System.Windows.Forms.Label();
            this.lBLCommunityBox = new System.Windows.Forms.Label();
            this.lblDivisionBox = new System.Windows.Forms.Label();
            this.lblDateofDeath = new System.Windows.Forms.Label();
            this.lblRank = new System.Windows.Forms.Label();
            this.lblRegNo = new System.Windows.Forms.Label();
            this.lblCommunity = new System.Windows.Forms.Label();
            this.lblDivision = new System.Windows.Forms.Label();
            this.lblGSurname = new System.Windows.Forms.Label();
            this.lblGsurnamebox = new System.Windows.Forms.Label();
            this.lblsurnamebox = new System.Windows.Forms.Label();
            this.lblSurname = new System.Windows.Forms.Label();
            this.grpCasualty.SuspendLayout();
            this.grpDetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpCasualty
            // 
            this.grpCasualty.Controls.Add(this.vScrollBar1);
            this.grpCasualty.Location = new System.Drawing.Point(32, 29);
            this.grpCasualty.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.grpCasualty.Name = "grpCasualty";
            this.grpCasualty.Padding = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.grpCasualty.Size = new System.Drawing.Size(371, 906);
            this.grpCasualty.TabIndex = 0;
            this.grpCasualty.TabStop = false;
            this.grpCasualty.Text = "Casualties";
            // 
            // vScrollBar1
            // 
            this.vScrollBar1.Location = new System.Drawing.Point(712, 38);
            this.vScrollBar1.Name = "vScrollBar1";
            this.vScrollBar1.Size = new System.Drawing.Size(17, 692);
            this.vScrollBar1.TabIndex = 1;
            // 
            // grpDetails
            // 
            this.grpDetails.Controls.Add(this.lblNextOfKinNameBox);
            this.grpDetails.Controls.Add(this.lblServedBox);
            this.grpDetails.Controls.Add(this.lblBuriedBox);
            this.grpDetails.Controls.Add(this.lblNextKin);
            this.grpDetails.Controls.Add(this.lblServed);
            this.grpDetails.Controls.Add(this.lblBuried);
            this.grpDetails.Controls.Add(this.lblDateOfDeathBox);
            this.grpDetails.Controls.Add(this.lblRankBox);
            this.grpDetails.Controls.Add(this.lblRegNoBox);
            this.grpDetails.Controls.Add(this.lBLCommunityBox);
            this.grpDetails.Controls.Add(this.lblDivisionBox);
            this.grpDetails.Controls.Add(this.lblDateofDeath);
            this.grpDetails.Controls.Add(this.lblRank);
            this.grpDetails.Controls.Add(this.lblRegNo);
            this.grpDetails.Controls.Add(this.lblCommunity);
            this.grpDetails.Controls.Add(this.lblDivision);
            this.grpDetails.Controls.Add(this.lblGSurname);
            this.grpDetails.Controls.Add(this.lblGsurnamebox);
            this.grpDetails.Controls.Add(this.lblsurnamebox);
            this.grpDetails.Controls.Add(this.lblSurname);
            this.grpDetails.Location = new System.Drawing.Point(419, 29);
            this.grpDetails.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.grpDetails.Name = "grpDetails";
            this.grpDetails.Padding = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.grpDetails.Size = new System.Drawing.Size(1069, 906);
            this.grpDetails.TabIndex = 1;
            this.grpDetails.TabStop = false;
            this.grpDetails.Text = "Details";
            // 
            // lblNextOfKinNameBox
            // 
            this.lblNextOfKinNameBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNextOfKinNameBox.Location = new System.Drawing.Point(291, 842);
            this.lblNextOfKinNameBox.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblNextOfKinNameBox.Name = "lblNextOfKinNameBox";
            this.lblNextOfKinNameBox.Size = new System.Drawing.Size(762, 52);
            this.lblNextOfKinNameBox.TabIndex = 19;
            this.lblNextOfKinNameBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblServedBox
            // 
            this.lblServedBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblServedBox.Location = new System.Drawing.Point(291, 762);
            this.lblServedBox.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblServedBox.Name = "lblServedBox";
            this.lblServedBox.Size = new System.Drawing.Size(762, 52);
            this.lblServedBox.TabIndex = 18;
            this.lblServedBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblBuriedBox
            // 
            this.lblBuriedBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblBuriedBox.Location = new System.Drawing.Point(291, 685);
            this.lblBuriedBox.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblBuriedBox.Name = "lblBuriedBox";
            this.lblBuriedBox.Size = new System.Drawing.Size(762, 52);
            this.lblBuriedBox.TabIndex = 17;
            this.lblBuriedBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblNextKin
            // 
            this.lblNextKin.AutoSize = true;
            this.lblNextKin.Location = new System.Drawing.Point(16, 853);
            this.lblNextKin.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblNextKin.Name = "lblNextKin";
            this.lblNextKin.Size = new System.Drawing.Size(245, 32);
            this.lblNextKin.TabIndex = 16;
            this.lblNextKin.Text = "Next of Kin-Name:";
            // 
            // lblServed
            // 
            this.lblServed.AutoSize = true;
            this.lblServed.Location = new System.Drawing.Point(16, 773);
            this.lblServed.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblServed.Name = "lblServed";
            this.lblServed.Size = new System.Drawing.Size(177, 32);
            this.lblServed.TabIndex = 15;
            this.lblServed.Text = "Served With:";
            // 
            // lblBuried
            // 
            this.lblBuried.AutoSize = true;
            this.lblBuried.Location = new System.Drawing.Point(16, 696);
            this.lblBuried.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblBuried.Name = "lblBuried";
            this.lblBuried.Size = new System.Drawing.Size(106, 32);
            this.lblBuried.TabIndex = 14;
            this.lblBuried.Text = "Buried:";
            // 
            // lblDateOfDeathBox
            // 
            this.lblDateOfDeathBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDateOfDeathBox.Location = new System.Drawing.Point(291, 548);
            this.lblDateOfDeathBox.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblDateOfDeathBox.Name = "lblDateOfDeathBox";
            this.lblDateOfDeathBox.Size = new System.Drawing.Size(502, 52);
            this.lblDateOfDeathBox.TabIndex = 13;
            this.lblDateOfDeathBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblDateOfDeathBox.UseCompatibleTextRendering = true;
            // 
            // lblRankBox
            // 
            this.lblRankBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRankBox.Location = new System.Drawing.Point(291, 475);
            this.lblRankBox.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblRankBox.Name = "lblRankBox";
            this.lblRankBox.Size = new System.Drawing.Size(502, 52);
            this.lblRankBox.TabIndex = 12;
            this.lblRankBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblRegNoBox
            // 
            this.lblRegNoBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRegNoBox.Location = new System.Drawing.Point(291, 397);
            this.lblRegNoBox.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblRegNoBox.Name = "lblRegNoBox";
            this.lblRegNoBox.Size = new System.Drawing.Size(502, 52);
            this.lblRegNoBox.TabIndex = 11;
            this.lblRegNoBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lBLCommunityBox
            // 
            this.lBLCommunityBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lBLCommunityBox.Location = new System.Drawing.Point(291, 320);
            this.lBLCommunityBox.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lBLCommunityBox.Name = "lBLCommunityBox";
            this.lBLCommunityBox.Size = new System.Drawing.Size(505, 52);
            this.lBLCommunityBox.TabIndex = 10;
            this.lBLCommunityBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDivisionBox
            // 
            this.lblDivisionBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDivisionBox.Location = new System.Drawing.Point(291, 237);
            this.lblDivisionBox.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblDivisionBox.Name = "lblDivisionBox";
            this.lblDivisionBox.Size = new System.Drawing.Size(505, 52);
            this.lblDivisionBox.TabIndex = 9;
            this.lblDivisionBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDateofDeath
            // 
            this.lblDateofDeath.AutoSize = true;
            this.lblDateofDeath.Location = new System.Drawing.Point(16, 559);
            this.lblDateofDeath.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblDateofDeath.Name = "lblDateofDeath";
            this.lblDateofDeath.Size = new System.Drawing.Size(197, 32);
            this.lblDateofDeath.TabIndex = 8;
            this.lblDateofDeath.Text = "Date of Death:";
            // 
            // lblRank
            // 
            this.lblRank.AutoSize = true;
            this.lblRank.Location = new System.Drawing.Point(16, 486);
            this.lblRank.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblRank.Name = "lblRank";
            this.lblRank.Size = new System.Drawing.Size(89, 32);
            this.lblRank.TabIndex = 7;
            this.lblRank.Text = "Rank:";
            // 
            // lblRegNo
            // 
            this.lblRegNo.AutoSize = true;
            this.lblRegNo.Location = new System.Drawing.Point(16, 408);
            this.lblRegNo.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblRegNo.Name = "lblRegNo";
            this.lblRegNo.Size = new System.Drawing.Size(134, 32);
            this.lblRegNo.TabIndex = 6;
            this.lblRegNo.Text = "Reg. No.:";
            // 
            // lblCommunity
            // 
            this.lblCommunity.AutoSize = true;
            this.lblCommunity.Location = new System.Drawing.Point(16, 331);
            this.lblCommunity.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblCommunity.Name = "lblCommunity";
            this.lblCommunity.Size = new System.Drawing.Size(166, 32);
            this.lblCommunity.TabIndex = 5;
            this.lblCommunity.Text = "Community:";
            // 
            // lblDivision
            // 
            this.lblDivision.AutoSize = true;
            this.lblDivision.Location = new System.Drawing.Point(16, 248);
            this.lblDivision.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblDivision.Name = "lblDivision";
            this.lblDivision.Size = new System.Drawing.Size(124, 32);
            this.lblDivision.TabIndex = 4;
            this.lblDivision.Text = "Division:";
            // 
            // lblGSurname
            // 
            this.lblGSurname.AutoSize = true;
            this.lblGSurname.Location = new System.Drawing.Point(16, 160);
            this.lblGSurname.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblGSurname.Name = "lblGSurname";
            this.lblGSurname.Size = new System.Drawing.Size(220, 32);
            this.lblGSurname.TabIndex = 3;
            this.lblGSurname.Text = "Given Surname:";
            // 
            // lblGsurnamebox
            // 
            this.lblGsurnamebox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblGsurnamebox.Location = new System.Drawing.Point(291, 149);
            this.lblGsurnamebox.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblGsurnamebox.Name = "lblGsurnamebox";
            this.lblGsurnamebox.Size = new System.Drawing.Size(502, 52);
            this.lblGsurnamebox.TabIndex = 2;
            this.lblGsurnamebox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblsurnamebox
            // 
            this.lblsurnamebox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblsurnamebox.Location = new System.Drawing.Point(291, 75);
            this.lblsurnamebox.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblsurnamebox.Name = "lblsurnamebox";
            this.lblsurnamebox.Size = new System.Drawing.Size(505, 52);
            this.lblsurnamebox.TabIndex = 1;
            this.lblsurnamebox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSurname
            // 
            this.lblSurname.AutoSize = true;
            this.lblSurname.Location = new System.Drawing.Point(16, 86);
            this.lblSurname.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lblSurname.Name = "lblSurname";
            this.lblSurname.Size = new System.Drawing.Size(138, 32);
            this.lblSurname.TabIndex = 0;
            this.lblSurname.Text = "Surname:";
            // 
            // frmCasualty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1504, 959);
            this.Controls.Add(this.grpDetails);
            this.Controls.Add(this.grpCasualty);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.MaximizeBox = false;
            this.Name = "frmCasualty";
            this.Text = "Casualty";
            this.Load += new System.EventHandler(this.Casualty_Load);
            this.grpCasualty.ResumeLayout(false);
            this.grpDetails.ResumeLayout(false);
            this.grpDetails.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpCasualty;
        private System.Windows.Forms.VScrollBar vScrollBar1;
        private System.Windows.Forms.GroupBox grpDetails;
        private System.Windows.Forms.Label lblGSurname;
        private System.Windows.Forms.Label lblGsurnamebox;
        private System.Windows.Forms.Label lblsurnamebox;
        private System.Windows.Forms.Label lblSurname;
        private System.Windows.Forms.Label lblDateofDeath;
        private System.Windows.Forms.Label lblRank;
        private System.Windows.Forms.Label lblRegNo;
        private System.Windows.Forms.Label lblCommunity;
        private System.Windows.Forms.Label lblDivision;
        private System.Windows.Forms.Label lblNextOfKinNameBox;
        private System.Windows.Forms.Label lblServedBox;
        private System.Windows.Forms.Label lblBuriedBox;
        private System.Windows.Forms.Label lblNextKin;
        private System.Windows.Forms.Label lblServed;
        private System.Windows.Forms.Label lblBuried;
        private System.Windows.Forms.Label lblDateOfDeathBox;
        private System.Windows.Forms.Label lblRankBox;
        private System.Windows.Forms.Label lblRegNoBox;
        private System.Windows.Forms.Label lBLCommunityBox;
        private System.Windows.Forms.Label lblDivisionBox;
    }
}