﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IndustryProject
{
    /// <summary>
    /// Not coded.
    /// </summary>
    public partial class newplace : Form
    {
        public newplace()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Load Method.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void newplace_Load(object sender, EventArgs e)
        {
            //What is needed
        }

        /// <summary>
        /// Closing the form.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
